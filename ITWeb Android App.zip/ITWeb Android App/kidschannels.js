const m3uContentkids = `#EXTINF:-1 tvg-id="" tvg-name="Hanuman (2005)" tvg-logo="https://image.tmdb.org/t/p/w600_and_h900_bestv2/xgjarOLCUK6x8dKZu3gJw7jEvBb.jpg" group-title="KIDS ➾ MOVIE (Hindi)",Hanuman (2005)
http://filex.tv:8080/movie/maazqamar/002450/277879.mp4
#EXTINF:-1 tvg-id="" tvg-name="CARTOON NET WORK" tvg-logo="https://i.imgur.com/mXgp2qD.png" group-title="IN ➾ KIDS",CARTOON NET WORK
http://filex.tv:8080/live/maazqamar/002450/5.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Nick Jr" tvg-logo="https://images.pluto.tv/channels/5f121460b73ac6000719fbaf/colorLogoPNG.png" group-title="IN ➾ KIDS",Nick Jr
http://filex.tv:8080/live/maazqamar/002450/9.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Nick HD +" tvg-logo="http://103.184.192.164:5001/jtvimage/Nick_HD_Plus.png" group-title="IN ➾ KIDS",Nick HD +
http://filex.tv:8080/live/maazqamar/002450/11.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Nick (Hindi)" tvg-logo="http://filex.tv:8080/images/8469d44204388be88885368360f3faed.png" group-title="IN ➾ KIDS",Nick (Hindi)
http://filex.tv:8080/live/maazqamar/002450/319.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Pogo (hindi)" tvg-logo="https://www.lyngsat.com/logo/tv/pp/pogo-in.png" group-title="IN ➾ KIDS",Pogo (hindi)
http://filex.tv:8080/live/maazqamar/002450/320.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Hangama" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hungama.png" group-title="IN ➾ KIDS",Hangama
http://filex.tv:8080/live/maazqamar/002450/123826.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DISNEY JUNIOR HINDI" tvg-logo="" group-title="IN ➾ KIDS",DISNEY JUNIOR HINDI
http://filex.tv:8080/live/maazqamar/002450/123848.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DISNEY CHANNEL" tvg-logo="https://logos-world.net/wp-content/uploads/2021/08/Disney-Channel-Logo-700x394.png" group-title="IN ➾ KIDS",DISNEY CHANNEL
http://filex.tv:8080/live/maazqamar/002450/246763.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DISCOVERY KIDS" tvg-logo="https://www.lyngsat.com/logo/tv/dd/discovery-kids-asia-us.png" group-title="IN ➾ KIDS",DISCOVERY KIDS
http://filex.tv:8080/live/maazqamar/002450/246765.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SONIC NICK HD" tvg-logo="https://www.lyngsat.com/logo/tv/nn/nickelodeon_sonic_us.png" group-title="IN ➾ KIDS",SONIC NICK HD
http://filex.tv:8080/live/maazqamar/002450/246767.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DISNEY JUNIOR HD" tvg-logo="https://www.lyngsat.com/logo/tv/dd/disney_junior_us.png" group-title="IN ➾ KIDS",DISNEY JUNIOR HD
http://filex.tv:8080/live/maazqamar/002450/246769.m3u8
#EXTINF:-1 tvg-id="" tvg-name="NICK HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/8/85/New_Nick_Logo_2015.png" group-title="IN ➾ KIDS",NICK HD
http://filex.tv:8080/live/maazqamar/002450/246770.m3u8
#EXTINF:-1 tvg-id="" tvg-name="KIDSZONE HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/kidzoneplus-pakistan-ee-pk.png" group-title="IN ➾ KIDS",KIDSZONE HD
http://filex.tv:8080/live/maazqamar/002450/246774.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PLANET FUN HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/planet-fun-uk.png" group-title="IN ➾ KIDS",PLANET FUN HD
http://filex.tv:8080/live/maazqamar/002450/246775.m3u8
#EXTINF:-1 tvg-id="" tvg-name="HOORA TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hoora-tv-uk.png" group-title="IN ➾ KIDS",HOORA TV HD
http://filex.tv:8080/live/maazqamar/002450/246778.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MINIMAX HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/minimax-hu.png" group-title="IN ➾ KIDS",MINIMAX HD
http://filex.tv:8080/live/maazqamar/002450/246779.m3u8


`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channelskids = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channelskids.push(currentChannel);
            }
        });

        return channelskids;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink6">
                    <div class="column">
                        <div class="card">
                          <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channelskids = parseM3U(m3uContentkids);
    document.getElementById("playlistContainerkids").innerHTML = generateHTML(channelskids);
