const m3uContentnews = `#EXTINF:-1 tvg-id="" tvg-name="92 NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/num/92-news-pk.png" group-title="PAKISTAN ➾ NEWS",92 NEWS 
http://filex.tv:8080/live/maazqamar/002450/52034.m3u8
#EXTINF:-1 tvg-id="" tvg-name="92 NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/num/92-news-pk.png" group-title="PAKISTAN ➾ NEWS",92 NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52035.m3u8
#EXTINF:-1 tvg-id="" tvg-name="BOL NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol_news_pk.png" group-title="PAKISTAN ➾ NEWS",BOL NEWS
http://filex.tv:8080/live/maazqamar/002450/52036.m3u8
#EXTINF:-1 tvg-id="" tvg-name="BOL NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol_news_pk.png" group-title="PAKISTAN ➾ NEWS",BOL NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52037.m3u8
#EXTINF:-1 tvg-id="" tvg-name="EXPRESS NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/ee/express-news-pk.png" group-title="PAKISTAN ➾ NEWS",EXPRESS NEWS 
http://filex.tv:8080/live/maazqamar/002450/52038.m3u8
#EXTINF:-1 tvg-id="" tvg-name="EXPRESS NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express-news-pk.png" group-title="PAKISTAN ➾ NEWS",EXPRESS NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52039.m3u8
#EXTINF:-1 tvg-id="" tvg-name="GEO NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ NEWS",GEO NEWS 
http://filex.tv:8080/live/maazqamar/002450/52040.m3u8
#EXTINF:-1 tvg-id="" tvg-name="GEO NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ NEWS",GEO NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52041.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ARY NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_news_asia.png" group-title="PAKISTAN ➾ NEWS",ARY NEWS 
http://filex.tv:8080/live/maazqamar/002450/52042.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ARY NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_news_asia.png" group-title="PAKISTAN ➾ NEWS",ARY NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52043.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SAMAA NEWS " tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWsYR2EoaMEqmvdZL8l8vC4nKRi5SJtmNKmQ&usqp=CAU" group-title="PAKISTAN ➾ NEWS",SAMAA NEWS 
http://filex.tv:8080/live/maazqamar/002450/52044.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SAMAA NEWS HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWsYR2EoaMEqmvdZL8l8vC4nKRi5SJtmNKmQ&usqp=CAU" group-title="PAKISTAN ➾ NEWS",SAMAA NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52045.m3u8
#EXTINF:-1 tvg-id="" tvg-name="AAJ NEWS" tvg-logo="https://www.lyngsat-logo.com/logo/tv/aa/aaj_tv_news.png" group-title="PAKISTAN ➾ NEWS",AAJ NEWS
http://filex.tv:8080/live/maazqamar/002450/52046.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CITY 41 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_41_tv.png" group-title="PAKISTAN ➾ NEWS",CITY 41 FHD
http://filex.tv:8080/live/maazqamar/002450/52051.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CITY 42" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_42_tv.png" group-title="PAKISTAN ➾ NEWS",CITY 42
http://filex.tv:8080/live/maazqamar/002450/52052.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CITY 44 " tvg-logo="https://www.lyngsat.com/logo/tv/uu/uk_44_uk.png" group-title="PAKISTAN ➾ NEWS",CITY 44 
http://filex.tv:8080/live/maazqamar/002450/52054.m3u8
#EXTINF:-1 tvg-id="" tvg-name="LAHORE NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ll/lahore_news_pk.png" group-title="PAKISTAN ➾ NEWS",LAHORE NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52056.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SINDH NEWS *" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv_news.png" group-title="PAKISTAN ➾ NEWS",SINDH NEWS *
http://filex.tv:8080/live/maazqamar/002450/52057.m3u8
#EXTINF:-1 tvg-id="" tvg-name="GNN NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/gg/gourmet-news-network-pk.png" group-title="PAKISTAN ➾ NEWS",GNN NEWS
http://filex.tv:8080/live/maazqamar/002450/52058.m3u8
#EXTINF:-1 tvg-id="" tvg-name="LAHORE RANG" tvg-logo="https://www.lyngsat.com/logo/tv/ll/lahore-rang-pk.png" group-title="PAKISTAN ➾ NEWS",LAHORE RANG
http://filex.tv:8080/live/maazqamar/002450/52060.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DAWN NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dawn_news_pk.png" group-title="PAKISTAN ➾ NEWS",DAWN NEWS
http://filex.tv:8080/live/maazqamar/002450/52061.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DUNIYA NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dunya_news_tv_pk.png" group-title="PAKISTAN ➾ NEWS",DUNIYA NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52066.m3u8
#EXTINF:-1 tvg-id="" tvg-name="NEWS ONE HD" tvg-logo="https://www.lyngsat.com/logo/tv/nn/news-one-pk.png" group-title="PAKISTAN ➾ NEWS",NEWS ONE HD
http://filex.tv:8080/live/maazqamar/002450/52068.m3u8
#EXTINF:-1 tvg-id="" tvg-name="24 NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/channel_24_pk.png" group-title="PAKISTAN ➾ NEWS",24 NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52070.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ABB TAK NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/abb_takk_pk.png" group-title="PAKISTAN ➾ NEWS",ABB TAK NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52071.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PTV NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_news_pk.png" group-title="PAKISTAN ➾ NEWS",PTV NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52073.m3u8
#EXTINF:-1 tvg-id="" tvg-name="KOHINOOR TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/kohenoor-news-pk.png" group-title="PAKISTAN ➾ NEWS",KOHINOOR TV HD
http://filex.tv:8080/live/maazqamar/002450/52074.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ROZE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/rr/roze_news_pk.png" group-title="PAKISTAN ➾ NEWS",ROZE TV HD
http://filex.tv:8080/live/maazqamar/002450/52075.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PUBLIC NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/public-news-pk.png" group-title="PAKISTAN ➾ NEWS",PUBLIC NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52226.m3u8
#EXTINF:-1 tvg-id="" tvg-name="7 NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/num/7_news_pk.png" group-title="PAKISTAN ➾ NEWS",7 NEWS HD
http://filex.tv:8080/live/maazqamar/002450/52227.m3u8
#EXTINF:-1 tvg-id="" tvg-name="HUM NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-news-pk.png" group-title="PAKISTAN ➾ NEWS",HUM NEWS HD
http://filex.tv:8080/live/maazqamar/002450/71178.m3u8
#EXTINF:-1 tvg-id="" tvg-name="KTN NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/kk/ktn-news-pk.png" group-title="PAKISTAN ➾ NEWS",KTN NEWS
http://filex.tv:8080/live/maazqamar/002450/79852.m3u8

#EXTINF:-1 tvg-id="" tvg-name="TIME NEWS" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ7FDLcNrVI65EIy4L8UezF9g94n5Qzj9gz6w&s" group-title="PAKISTAN ➾ NEWS",TIME NEWS
https://cdn24lhr.tamashaweb.com:8087/jazzauth/TimeNews-abr/live/vsat-109L/chunks.m3u8

#EXTINF:-1 tvg-id="" tvg-name="KHYBER NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-news-pk.png" group-title="PAKISTAN ➾ NEWS",KHYBER NEWS 
http://filex.tv:8080/live/maazqamar/002450/189485.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MASHRIQ TV *" tvg-logo="https://www.lyngsat.com/logo/tv/mm/mashriq_tv_pk.png" group-title="PAKISTAN ➾ NEWS",MASHRIQ TV *
http://filex.tv:8080/live/maazqamar/002450/190144.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ABN NWES HD" tvg-logo="" group-title="PAKISTAN ➾ NEWS",ABN NWES HD
http://filex.tv:8080/live/maazqamar/002450/395096.m3u8
`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channels3 = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channels3.push(currentChannel);
            }
        });

        return channels3;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink3">
            
                    <div class="column">
                        <div class="card">
                           <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channels3 = parseM3U(m3uContentnews);
    document.getElementById("playlistContainer3").innerHTML = generateHTML(channels3);
