const m3uContentindent = `#EXTINF:-1 tvg-id="" tvg-name=" ZEE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/zz/zee-tv-in.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE TV HD
http://filex.tv:8080/live/maazqamar/002450/13.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SONY SET HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/set_in.png" group-title="INDIAN ➾ ENTERTAINMENT", SONY SET HD
http://filex.tv:8080/live/maazqamar/002450/15.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR PLUS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-plus-hk.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR PLUS HD
http://filex.tv:8080/live/maazqamar/002450/17.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" COLORS HD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/colors-in.png" group-title="INDIAN ➾ ENTERTAINMENT", COLORS HD
http://filex.tv:8080/live/maazqamar/002450/19.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR BHARAT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-bharat-hk-in.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR BHARAT HD
http://filex.tv:8080/live/maazqamar/002450/21.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" & TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/and_tv_in.png" group-title="INDIAN ➾ ENTERTAINMENT", & TV HD
http://filex.tv:8080/live/maazqamar/002450/23.m3u8
#EXTINF:-1 tvg-id="" tvg-name="IN| SONY SAB HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sab-tv-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN| SONY SAB HD
http://filex.tv:8080/live/maazqamar/002450/25.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR GOLD SELECT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star_gold_in_select_hd.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR GOLD SELECT HD
http://filex.tv:8080/live/maazqamar/002450/28.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR GOLD HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-gold-hd-india-in.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR GOLD HD
http://filex.tv:8080/live/maazqamar/002450/29.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR GOLD 2 HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Star_Gold_2.svg/1376px-Star_Gold_2.svg.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR GOLD 2 HD
http://filex.tv:8080/live/maazqamar/002450/31.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SONY MAX 2 HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_MAX2.png" group-title="INDIAN ➾ ENTERTAINMENT", SONY MAX 2 HD
http://filex.tv:8080/live/maazqamar/002450/32.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SONY MAX HD" tvg-logo="http://filex.tv:8080/images/93a3eb73578a3d9fc24502ad866b1d7f.png" group-title="INDIAN ➾ ENTERTAINMENT", SONY MAX HD
http://filex.tv:8080/live/maazqamar/002450/33.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" & PICTURES HD" tvg-logo="http://filex.tv:8080/images/06ae3d7e2037a51f743e3b718f5f70e9.png" group-title="INDIAN ➾ ENTERTAINMENT", & PICTURES HD
http://filex.tv:8080/live/maazqamar/002450/35.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZEE CINEMA HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Cinema_HD.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE CINEMA HD
http://filex.tv:8080/live/maazqamar/002450/37.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" COLORS CINEPLEX HD" tvg-logo="http://filex.tv:8080/images/c540853bcc71d20eb039cfa614b4b900.png" group-title="INDIAN ➾ ENTERTAINMENT", COLORS CINEPLEX HD
http://filex.tv:8080/live/maazqamar/002450/43.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZEE ANMOL HD" tvg-logo="http://filex.tv:8080/images/9e10122b535181988d7ad031b583b335.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE ANMOL HD
http://filex.tv:8080/live/maazqamar/002450/48.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZEE ACTION HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Action.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE ACTION HD
http://filex.tv:8080/live/maazqamar/002450/50.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" DHINCHAAK HD" tvg-logo="http://filex.tv:8080/images/710ae7950a9c977637378286828b980a.png" group-title="INDIAN ➾ ENTERTAINMENT", DHINCHAAK HD
http://filex.tv:8080/live/maazqamar/002450/51.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" COLORS RISHTE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrYYOBNUSNFkPvXP7wOCSbKt45IULkf6e66Q&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT", COLORS RISHTE HD
http://filex.tv:8080/live/maazqamar/002450/52.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZEE ANMOL CINEMA HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Anmol_Cinema.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE ANMOL CINEMA HD
http://filex.tv:8080/live/maazqamar/002450/54.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" & FLIX HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuANx7s-Dxxy35uMqXRag0lUXvXhc19y7DCw&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT", & FLIX HD
http://filex.tv:8080/live/maazqamar/002450/55.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SONY PAL HD" tvg-logo="http://sagraecdnems06.cdnsrv.jio.com/jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Pal.png" group-title="INDIAN ➾ ENTERTAINMENT", SONY PAL HD
http://filex.tv:8080/live/maazqamar/002450/56.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" COLOUR CINEPLEX BOLLYWOOD HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQu18Rs2fkZ8b_AmXmYEOsxiQlicYY9n4ukgQ&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT", COLOUR CINEPLEX BOLLYWOOD HD
http://filex.tv:8080/live/maazqamar/002450/58.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" B4U MOVIE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQL-ajdmye9QnGBqgEjmP6TiNTkV7trgw2jwQ&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT", B4U MOVIE HD
http://filex.tv:8080/live/maazqamar/002450/60.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SONY PIX HD" tvg-logo="http://filex.tv:8080/images/de357c9c796e9a5761b57088271d7a06.png" group-title="INDIAN ➾ ENTERTAINMENT", SONY PIX HD
http://filex.tv:8080/live/maazqamar/002450/75.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR UTSAV HD" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/6/65/Star_utsav.png/revision/latest?cb=20210520175932" group-title="INDIAN ➾ ENTERTAINMENT", STAR UTSAV HD
http://filex.tv:8080/live/maazqamar/002450/103.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZING HD" tvg-logo="http://filex.tv:8080/images/4effc0b88d9c1125754425708f0f2452.png" group-title="INDIAN ➾ ENTERTAINMENT", ZING HD
http://filex.tv:8080/live/maazqamar/002450/106.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" MOVIE NOW HD" tvg-logo="https://i.imgur.com/LP27MEL.png" group-title="INDIAN ➾ ENTERTAINMENT", MOVIE NOW HD
http://filex.tv:8080/live/maazqamar/002450/113.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR MOVIES HD" tvg-logo="https://imagesstartv.whatsonindia.com/dasimages/channel/landscape/100x75/d3ZNcauZ.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR MOVIES HD
http://filex.tv:8080/live/maazqamar/002450/52223.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR MOVIES SELECT ENGLISH HDj" tvg-logo="https://tvscheduleindia.com/assets/brand/channels/i7ifGMFv.png" group-title="INDIAN ➾ ENTERTAINMENT", STAR MOVIES SELECT ENGLISH HDj
http://filex.tv:8080/live/maazqamar/002450/52225.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ENTER 10 MOVIE HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", ENTER 10 MOVIE HD
http://filex.tv:8080/live/maazqamar/002450/52231.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" BIG MAGIC HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/7/7b/BIG_Magic_Logo.jpg" group-title="INDIAN ➾ ENTERTAINMENT", BIG MAGIC HD
http://filex.tv:8080/live/maazqamar/002450/52404.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" & PRIVE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMeDsn6WxeHhO_0LNmydM3Vw0qGoWREJtIxw&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT", & PRIVE HD
http://filex.tv:8080/live/maazqamar/002450/53043.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" COLORS INFINITY HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", COLORS INFINITY HD
http://filex.tv:8080/live/maazqamar/002450/87330.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" PTC PUNJABI HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", PTC PUNJABI HD
http://filex.tv:8080/live/maazqamar/002450/131564.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" PTC SIMRAN HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", PTC SIMRAN HD
http://filex.tv:8080/live/maazqamar/002450/131565.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SHEMAROO TV HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", SHEMAROO TV HD
http://filex.tv:8080/live/maazqamar/002450/142889.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR GOLD THRILLS HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", STAR GOLD THRILLS HD
http://filex.tv:8080/live/maazqamar/002450/189473.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" STAR GOLD ROMANCE HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", STAR GOLD ROMANCE HD
http://filex.tv:8080/live/maazqamar/002450/189474.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ZEE CAFE HD" tvg-logo="http://103.184.192.164:5001/jtvimage/Zee_Cafe_HD.png" group-title="INDIAN ➾ ENTERTAINMENT", ZEE CAFE HD
http://filex.tv:8080/live/maazqamar/002450/279284.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" MAHA MOVIE HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", MAHA MOVIE HD
http://filex.tv:8080/live/maazqamar/002450/282085.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" DHAMAKA MOVIE B4U HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT", DHAMAKA MOVIE B4U HD
http://filex.tv:8080/live/maazqamar/002450/282086.m3u8

`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channelsindent = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channelsindent.push(currentChannel);
            }
        });

        return channelsindent;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink4">
                    <div class="column">
                        <div class="card">
                          <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channelsindent = parseM3U(m3uContentindent);
    document.getElementById("playlistContainerindent").innerHTML = generateHTML(channelsindent);
