const m3uContent = `#EXTINF:-1 tvg-id="" tvg-name="PTV SPORTS SD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfBGNJKydmisM41NKVx6o9xW4MoEwgeQS6q-8Sc2Tu8Q&s" group-title="CRICKET ➾",PTV SPORTS SD
http://filex.tv:8080/live/maazqamar/002450/250211.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PTV SPORTS HD." tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTfBGNJKydmisM41NKVx6o9xW4MoEwgeQS6q-8Sc2Tu8Q&s" group-title="CRICKET ➾",PTV SPORTS HD.
http://filex.tv:8080/live/maazqamar/002450/190767.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 01" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)", CRICKET 01
http://filex.tv:8080/live/maazqamar/002450/141872.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 02" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)",CRICKET 02
http://filex.tv:8080/live/maazqamar/002450/191878.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 03" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)",CRICKET 03
http://filex.tv:8080/live/maazqamar/002450/178637.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 04" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)",CRICKET 04
http://filex.tv:8080/live/maazqamar/002450/191879.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 05" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)",CRICKET 05
http://filex.tv:8080/live/maazqamar/002450/141723.m3u8
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 06" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfVxvZ2ypRtZBq_UDHpfp93o-UeXBf02sQhU3fNGGbNeOpXko3fGBYT0k&s=10" group-title="T20 ➾ WORLD CUP (2024)",CRICKET 06
http://filex.tv:8080/live/maazqamar/002450/191819.m3u8
#EXTINF:-1 tvg-id="" tvg-name="18 SPORTS HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbMdMT6RbARTBfVI38LhwxZRH4hNhja4089A&s" group-title="CRICKET ➾",18 SPORTS HD
http://filex.tv:8080/live/maazqamar/002450/52077.m3u8
#EXTINF:-1 tvg-id="" tvg-name="GEO SUPER HD" tvg-logo="https://yt3.googleusercontent.com/DVv-My1F3Wbpw_R6gh0HBF00Na35AfzQGzs3Wjey9-s2p740NspDESy8AtqkVIcZWe30tsZ_oQ=s900-c-k-c0x00ffffff-no-rj" group-title="CRICKET ➾",GEO SUPER HD
http://filex.tv:8080/live/maazqamar/002450/52080.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SONY TEN 1 HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrmywQMe-6nZe5Y8VbaEAOLECOzKnSrDbScw&s" group-title="CRICKET ➾",SONY TEN 1 HD
http://filex.tv:8080/live/maazqamar/002450/52083.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SONY TEN 2 HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbdho8ETskFR9WpDlOrqbyuno-b3153QpeAQ&s" group-title="CRICKET ➾",SONY TEN 2 HD
http://filex.tv:8080/live/maazqamar/002450/52085.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SONY TEN 3 HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6tNG_IX5IaWO1rNjiSsjDxZQoV3uKM4IMsA&s" group-title="CRICKET ➾",SONY TEN 3 HD
http://filex.tv:8080/live/maazqamar/002450/52086.m3u8
#EXTINF:-1 tvg-id="" tvg-name="STAR SPORTS 1 HD" tvg-logo="https://www.indiantelevision.com/sites/default/files/images/tv-images/2018/12/06/star-k.jpg" group-title="CRICKET ➾",STAR SPORTS 1 HD
http://filex.tv:8080/live/maazqamar/002450/52094.m3u8
#EXTINF:-1 tvg-id="" tvg-name="STAR SPORTS 2 HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjpsCwohEnTBneBaHxGUStKs_LmtZtUbuhMg&s" group-title="CRICKET ➾",STAR SPORTS 2 HD
http://filex.tv:8080/live/maazqamar/002450/52096.m3u8
#EXTINF:-1 tvg-id="" tvg-name="STAR SPORTS SELECT 1 HD" tvg-logo="https://i.ibb.co/rbgvLYd/Star-Sports-Select-1-X-Vision.png" group-title="CRICKET ➾",STAR SPORTS SELECT 1 HD
http://filex.tv:8080/live/maazqamar/002450/52098.m3u8
#EXTINF:-1 tvg-id="" tvg-name="STAR SPORTS SELECT 2 HD" tvg-logo="https://i.ibb.co/dPP0vQS/Star-Sports-Select-2-X-Vision.png" group-title="CRICKET ➾",STAR SPORTS SELECT 2 HD
http://filex.tv:8080/live/maazqamar/002450/52100.m3u8
#EXTINF:-1 tvg-id="" tvg-name="TEN SPORTS HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDRoum_fljydrrcgXChrBl50SMRAiCJ1Oicg&s" group-title="CRICKET ➾",TEN SPORTS HD
http://filex.tv:8080/live/maazqamar/002450/52106.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DD SPORTS" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZG_YQKgwxE8X9rWVZk09_5ijzLNQ-5q_BZQ&s" group-title="CRICKET ➾",DD SPORTS
http://filex.tv:8080/live/maazqamar/002450/52107.m3u8
#EXTINF:-1 tvg-id="" tvg-name="WILLOW CRICKET HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKGB1laoexkcORqo1-VQEqitmHRxa9N2bzkw&s" group-title="CRICKET ➾",WILLOW CRICKET HD
http://filex.tv:8080/live/maazqamar/002450/52109.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ARY SPORTS HD" tvg-logo="https://yt3.googleusercontent.com/Ve4nWezHoaSvbvgaIoLVq1jsQOjx5ogIA_iFhL8fvNHyXLqFFcqi9rqvOVbHko_zsJ2oFVAkrg=s900-c-k-c0x00ffffff-no-rj" group-title="CRICKET ➾",ARY SPORTS HD
http://filex.tv:8080/live/maazqamar/002450/62393.m3u8
#EXTINF:-1 tvg-id="" tvg-name="STAR SPORTS 1 HINDI FHD " tvg-logo="https://www.indiantelevision.com/sites/default/files/images/tv-images/2018/12/06/star-k.jpg" group-title="CRICKET ➾",STAR SPORTS 1 HINDI FHD 
http://filex.tv:8080/live/maazqamar/002450/90342.m3u8
#EXTINF:-1 tvg-id="" tvg-name="T SPORTS" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0s2lhj4Z8vIWO1xsGLz32xh3-7bnnwD55tg&s" group-title="CRICKET ➾",BD | T SPORTS
http://filex.tv:8080/live/maazqamar/002450/111409.m3u8
#EXTINF:-1 tvg-id="" tvg-name="FAST SPORTS " tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQckpwDrPbdZVhtY9NVsdrlX3TFJu6dtnZiQ&s" group-title="CRICKET ➾",FAST SPORTS 
http://filex.tv:8080/live/maazqamar/002450/277207.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SKY SPORTS CRICKET FHD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkiK2KOBrfGgMGvBg6-dHmiGyRNYgdK6CaIA&s" group-title="CRICKET ➾", SKY SPORTS CRICKET FHD
http://filex.tv:8080/live/maazqamar/002450/250199.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SUPER SPORTS CRICKET " tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTsqqlUHT615UhCh5dDMBJhOg-YEjiZhPkQ0w&s" group-title="CRICKET ➾",AF | SUPER SPORTS CRICKET 
http://filex.tv:8080/live/maazqamar/002450/53044.m3u8
#EXTINF:-1 tvg-id="" tvg-name="TEN CRICKET HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSasHEB1s_iitApcYnJ_M_T7NhkKa171yGhBA&s" group-title="CRICKET ➾",TEN CRICKET HD
http://filex.tv:8080/live/maazqamar/002450/99833.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ASTRO CRICKET" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREiBx7OXqdgpMTiVcP6vDIwcWnE4qbFpwzMg&s" group-title="CRICKET ➾",ASTRO CRICKET
http://filex.tv:8080/live/maazqamar/002450/297577.m3u8

#EXTINF:-1 tvg-id="" tvg-name="NL | ZIGGO SPORT  GOLF" tvg-logo="https://i.imgur.com/VJy6Mjs.png" group-title="GOLF➾SPORTS",NL | ZIGGO SPORT  GOLF
http://filex.tv:8080/live/maazqamar/002450/187438.m3u8

`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channels = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channels.push(currentChannel);
            }
        });

        return channels;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink">
                    <div class="column">
                        <div class="card">
                          <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channels = parseM3U(m3uContent);
    document.getElementById("playlistContainer").innerHTML = generateHTML(channels);
