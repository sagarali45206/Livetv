const m3uContentent = `#EXTINF:-1 tvg-id="" tvg-name=" HUM TV " tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum_tv_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", HUM TV 
http://filex.tv:8080/live/maazqamar/002450/110033.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" HUM TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum_tv_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", HUM TV HD
http://filex.tv:8080/live/maazqamar/002450/110034.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ARY DIGITAL" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_digital_asia.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ARY DIGITAL
http://filex.tv:8080/live/maazqamar/002450/110036.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ARY DIGITAL HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_digital_asia.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ARY DIGITAL HD
http://filex.tv:8080/live/maazqamar/002450/110038.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" GEO ENTERTAINMENT" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", GEO ENTERTAINMENT
http://filex.tv:8080/live/maazqamar/002450/110040.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" GEO ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", GEO ENTERTAINMENT HD
http://filex.tv:8080/live/maazqamar/002450/110041.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" BOL ENTERTAINMENT " tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol-entertainment-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", BOL ENTERTAINMENT 
http://filex.tv:8080/live/maazqamar/002450/110043.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" BOL ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol-entertainment-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", BOL ENTERTAINMENT HD
http://filex.tv:8080/live/maazqamar/002450/110044.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" EXPRESS ENTERTAINMENT " tvg-logo="https://www.lyngsat.com/logo/tv/ee/express_entertainment_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", EXPRESS ENTERTAINMENT 
http://filex.tv:8080/live/maazqamar/002450/110046.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" EXPRESS ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express_entertainment_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", EXPRESS ENTERTAINMENT HD
http://filex.tv:8080/live/maazqamar/002450/110047.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ARY ZINDAGI" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_zindagi_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ARY ZINDAGI
http://filex.tv:8080/live/maazqamar/002450/110049.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" GEO KAHANI" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_kahani_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", GEO KAHANI
http://filex.tv:8080/live/maazqamar/002450/110052.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" AAJ ENTERTAINMENT" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aaj_entertainment_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", AAJ ENTERTAINMENT
http://filex.tv:8080/live/maazqamar/002450/110055.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" HUM SITARY" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-sitaray-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", HUM SITARY
http://filex.tv:8080/live/maazqamar/002450/110058.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" A PLUS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/a-plus-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", A PLUS HD
http://filex.tv:8080/live/maazqamar/002450/110062.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ATV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/atv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ATV HD
http://filex.tv:8080/live/maazqamar/002450/110065.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" PTV HOME " tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv-home-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", PTV HOME 
http://filex.tv:8080/live/maazqamar/002450/110067.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" PLAY TV" tvg-logo="https://www.lyngsat.com/logo/tv/pp/play-entertainment-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", PLAY TV
http://filex.tv:8080/live/maazqamar/002450/110068.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ARY QTV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_qtv.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ARY QTV HD
http://filex.tv:8080/live/maazqamar/002450/110071.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SAB TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sab-tv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", SAB TV HD
http://filex.tv:8080/live/maazqamar/002450/110075.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" AAN TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aan-tv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", AAN TV HD
http://filex.tv:8080/live/maazqamar/002450/110076.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" URDU 1 HD " tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaQZeEyawlNdVjokVYB6X9Yv2XmV7z-tCcgA&usqp=CAU" group-title="PAKISTAN ➾ ENTERTAINMENT ", URDU 1 HD 
http://filex.tv:8080/live/maazqamar/002450/110078.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" MUN TV" tvg-logo="https://www.lyngsat.com/logo/tv/mm/mun-tv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", MUN TV
http://filex.tv:8080/live/maazqamar/002450/110079.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" KTN TV" tvg-logo="https://www.lyngsat.com/logo/tv/kk/ktn_tv_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", KTN TV
http://filex.tv:8080/live/maazqamar/002450/110081.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" KASHISH TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/kashish-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", KASHISH TV HD
http://filex.tv:8080/live/maazqamar/002450/110084.m3u8
#EXTINF:-1 tvg-id="" tvg-name="DISCOVER PAKISTAN" tvg-logo="https://www.lyngsat.com/logo/tv/dd/discover-pakistan-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", DISCOVER PAKISTAN
http://filex.tv:8080/live/maazqamar/002450/110087.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SINDH TV" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", SINDH TV
http://filex.tv:8080/live/maazqamar/002450/110090.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" AUR LIVE" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aur-life-hd-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", AUR LIVE
http://filex.tv:8080/live/maazqamar/002450/110091.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SEE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/see_tv_pk_hd.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", SEE TV HD
http://filex.tv:8080/live/maazqamar/002450/110093.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" GREEN TV" tvg-logo="https://www.lyngsat.com/logo/tv/gg/green-entertainment-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", GREEN TV
http://filex.tv:8080/live/maazqamar/002450/110094.m3u8
#EXTINF:-1 tvg-id="" tvg-name="  WASEB TV" tvg-logo="https://www.lyngsat.com/logo/tv/ww/waseb_tv.png" group-title="PAKISTAN ➾ ENTERTAINMENT ",  WASEB TV
http://filex.tv:8080/live/maazqamar/002450/110095.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" RAAVI HD" tvg-logo="https://www.lyngsat.com/logo/tv/rr/raavi_tv.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", RAAVI HD
http://filex.tv:8080/live/maazqamar/002450/110099.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILMAX" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmax_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILMAX
http://filex.tv:8080/live/maazqamar/002450/110100.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" SILVER SCREEN" tvg-logo="https://www.lyngsat.com/logo/tv/ss/silver_screen_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", SILVER SCREEN
http://filex.tv:8080/live/maazqamar/002450/110102.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILMAZIA PUNJABI" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia-punjabi-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILMAZIA PUNJABI
http://filex.tv:8080/live/maazqamar/002450/110103.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILMAZIA GAANE" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia-gaane-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILMAZIA GAANE
http://filex.tv:8080/live/maazqamar/002450/110104.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILMAZIA PASHTO" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia-pashto-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILMAZIA PASHTO
http://filex.tv:8080/live/maazqamar/002450/110105.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILMAZIA" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILMAZIA
http://filex.tv:8080/live/maazqamar/002450/110107.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" FILM WORLD" tvg-logo="https://www.lyngsat.com/logo/tv/ff/film-world-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", FILM WORLD
http://filex.tv:8080/live/maazqamar/002450/110114.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" KHYBER TV" tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-middle-east-tv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", KHYBER TV
http://filex.tv:8080/live/maazqamar/002450/189484.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" ISAAC TV" tvg-logo="https://www.lyngsat.com/logo/tv/ii/isaac_tv.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", ISAAC TV
http://filex.tv:8080/live/maazqamar/002450/190764.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" BARKAT TV" tvg-logo="https://www.lyngsat.com/logo/tv/bb/barkat-tv-pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", BARKAT TV
http://filex.tv:8080/live/maazqamar/002450/190765.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" GAWAHI TV" tvg-logo="https://www.lyngsat.com/logo/tv/gg/gawahi_tv_pk.png" group-title="PAKISTAN ➾ ENTERTAINMENT ", GAWAHI TV

`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channels2 = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channels2.push(currentChannel);
            }
        });

        return channels2;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink2">

                    <div class="column">
                        <div class="card">
                         <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channels2 = parseM3U(m3uContentent);
    document.getElementById("playlistContainer2").innerHTML = generateHTML(channels2);
