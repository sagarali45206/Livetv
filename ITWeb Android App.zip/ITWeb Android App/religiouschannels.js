const m3uContentrel = `#EXTINF:-1 tvg-id="" tvg-name="QURAN MUJEED HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqIunp2uh2ml7qunCMxZMnnK0LlcU5J3trYduXFFfpeU1swjI2yuY0h3g&s=10" group-title="PK ➾ SLAMIC",QURAN MUJEED HD
http://filex.tv:8080/live/maazqamar/002450/311.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MAKKAH TV HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/a/a2/Makkah_logo.png" group-title="PK ➾ SLAMIC",MAKKAH TV HD
http://filex.tv:8080/live/maazqamar/002450/52112.m3u8
#EXTINF:-1 tvg-id="" tvg-name="NAAT HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxVegvmdQykVe_OUnUo0QfLYlCRLeQs-TrdA&usqp=CAU" group-title="PK ➾ SLAMIC",NAAT HD
http://filex.tv:8080/live/maazqamar/002450/139481.m3u8
#EXTINF:-1 tvg-id="" tvg-name="NOOR TV HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNW5YcMFmUmCkVaFvHjMjRHPYsI79RYDpoAA&usqp=CAU" group-title="PK ➾ SLAMIC",NOOR TV HD
http://filex.tv:8080/live/maazqamar/002450/141305.m3u8
#EXTINF:-1 tvg-id="" tvg-name="SAUDI SUNNAH HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sunna-tv-sa.png" group-title="PK ➾ SLAMIC",SAUDI SUNNAH HD
http://filex.tv:8080/live/maazqamar/002450/247145.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MADANI CHANNEL HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/madani-channel-pk.png" group-title="PK ➾ SLAMIC",MADANI CHANNEL HD
http://filex.tv:8080/live/maazqamar/002450/247146.m3u8
#EXTINF:-1 tvg-id="" tvg-name="KARBALA TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/karbala_satellite_channel.png" group-title="PK ➾ SLAMIC",KARBALA TV HD
http://filex.tv:8080/live/maazqamar/002450/247147.m3u8
#EXTINF:-1 tvg-id="" tvg-name="AHLEBAIT TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ahlebait.png" group-title="PK ➾ SLAMIC",AHLEBAIT TV HD
http://filex.tv:8080/live/maazqamar/002450/247148.m3u8
#EXTINF:-1 tvg-id="" tvg-name="HADI TV HD" tvg-logo="https://en.haditv.co.uk/pics/logo.png" group-title="PK ➾ SLAMIC",HADI TV HD
http://filex.tv:8080/live/maazqamar/002450/247149.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ARY QTV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_qtv.png" group-title="PK ➾ SLAMIC",ARY QTV HD
http://filex.tv:8080/live/maazqamar/002450/247150.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PEACE TV URDU HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/peace_tv_ae_urdu.png" group-title="PK ➾ SLAMIC",PEACE TV URDU HD
http://filex.tv:8080/live/maazqamar/002450/247151.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PEACE TV ENG HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/peace-tv-english-ae.png" group-title="PK ➾ SLAMIC",PEACE TV ENG HD
http://filex.tv:8080/live/maazqamar/002450/247152.m3u8
#EXTINF:-1 tvg-id="" tvg-name="PAIGHAM TV URDU HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/paigham_tv_pk.png" group-title="PK ➾ SLAMIC",PAIGHAM TV URDU HD
http://filex.tv:8080/live/maazqamar/002450/247153.m3u8
#EXTINF:-1 tvg-id="" tvg-name="MUNTAZIR TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/muntazar-tv-pk.png" group-title="PK ➾ SLAMIC",MUNTAZIR TV HD
http://filex.tv:8080/live/maazqamar/002450/247154.m3u8
`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channelsrel = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channelsrel.push(currentChannel);
            }
        });

        return channelsrel;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink7">
                    <div class="column">
                        <div class="card">
                          <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channelsrel = parseM3U(m3uContentrel);
    document.getElementById("playlistContainerrel").innerHTML = generateHTML(channelsrel);
