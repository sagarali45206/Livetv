const m3uContentindnews = `#EXTINF:-1 tvg-id="" tvg-name="News18 India" tvg-logo="" group-title="INDIAN ➾ NEWS",IND: News18 India
http://filex.tv:8080/live/maazqamar/002450/288625.m3u8
#EXTINF:-1 tvg-id="" tvg-name="ABP News HD" tvg-logo="" group-title="INDIAN ➾ NEWS",IND: ABP News HD
http://filex.tv:8080/live/maazqamar/002450/288608.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" T_NEWS" tvg-logo="" group-title="INDIAN ➾ NEWS", T_NEWS
http://filex.tv:8080/live/maazqamar/002450/288549.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" Survana_news" tvg-logo="" group-title="INDIAN ➾ NEWS", Survana_news
http://filex.tv:8080/live/maazqamar/002450/288545.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" Sadhna_Prime_News" tvg-logo="" group-title="INDIAN ➾ NEWS", Sadhna_Prime_News
http://filex.tv:8080/live/maazqamar/002450/288540.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" MH_ONE_NEWS" tvg-logo="" group-title="INDIAN ➾ NEWS", MH_ONE_NEWS
http://filex.tv:8080/live/maazqamar/002450/288528.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" Manorama_News_North" tvg-logo="" group-title="INDIAN ➾ NEWS", Manorama_News_North
http://filex.tv:8080/live/maazqamar/002450/288524.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" Manorama_News_Central" tvg-logo="" group-title="INDIAN ➾ NEWS", Manorama_News_Central
http://filex.tv:8080/live/maazqamar/002450/288523.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" I_NEWS" tvg-logo="" group-title="INDIAN ➾ NEWS", I_NEWS
http://filex.tv:8080/live/maazqamar/002450/288508.m3u8
#EXTINF:-1 tvg-id="" tvg-name=" CVR_NEWS" tvg-logo="" group-title="INDIAN ➾ NEWS", CVR_NEWS
http://filex.tv:8080/live/maazqamar/002450/288502.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Ind-news: Wion News" tvg-logo="" group-title="INDIAN ➾ NEWS",Ind-news: Wion News
http://filex.tv:8080/live/maazqamar/002450/288490.m3u8
#EXTINF:-1 tvg-id="" tvg-name="Republic News India" tvg-logo="" group-title="INDIAN ➾ NEWS",Ind-loc: Republic News India
http://filex.tv:8080/live/maazqamar/002450/288454.m3u8

`;

    function parseM3U(content) {
        const lines = content.split("\n");
        const channelsindnews = [];
        let currentChannel = {};

        lines.forEach(line => {
            if (line.startsWith("#EXTINF:")) {
                currentChannel = {};
                const nameMatch = line.match(/tvg-name="([^"]*)"/);
                const logoMatch = line.match(/tvg-logo="([^"]*)"/);
                currentChannel.name = nameMatch ? nameMatch[1] : "";
                currentChannel.logo = logoMatch ? logoMatch[1] : "";
            } else if (line.startsWith("http")) {
                currentChannel.url = line.trim();
                channelsindnews.push(currentChannel);
            }
        });

        return channelsindnews;
    }

    function generateHTML(channels) {
        return channels.map(channel => `
            <div class="channel-list" id="vidlink5">
                    <div class="column">
                        <div class="card">
                           <a href="intent:${channel.url}#Intent;package=com.genuine.leone;end" rel="noreferrer noopener" target="_blank">
                    <img alt="${channel.name}" src="${channel.logo}" onerror="this.onerror=null;this.src='https://s3-us-west-2.amazonaws.com/anchor-generated-image-bank/staging/podcast_uploaded_nologo400/38909171/38909171-1709664849186-7c033f87c89c2.jpg';"/>
                    ${channel.name}
                </a>
                        </div>
                    </div>
            </div>
        `).join("");
    }

    const channelsindnews = parseM3U(m3uContentindnews);
    document.getElementById("playlistContainerindnews").innerHTML = generateHTML(channelsindnews);
